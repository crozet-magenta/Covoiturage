<?php

/**
* 
*/
class Paths
{
    
}