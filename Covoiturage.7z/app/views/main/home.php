<section>
    <h1 class="section-title">Derniers voyages proposés</h1>
    <article class="path">
        <h2 class="path-title">Paris - Marseille</h2>
        <p class="path-details">Départ le 25 mai 2015 à 12h30, 3 sièges, 120€</p>
    </article>
    <article class="path">
        <h2 class="path-title">Marseille - Aix en provence</h2>
        <p class="path-details">Départ le 20 novembre 2014 à 8h30, 2 sièges, 2€</p>
    </article>
    <article class="path">
        <h2 class="path-title">Marseille - Aix en provence</h2>
        <p class="path-details">Départ le 22 novembre 2014 à 16h30, 5 sièges, 3.5€</p>
    </article>
    <article class="path">
        <h2 class="path-title">Martigues - Marseille</h2>
        <p class="path-details">Départ le 12 novembre 2014 à 8h00, 2 sièges, 3€</p>
    </article>
    <article class="path">
        <h2 class="path-title">Vitrolles - Salon de provence</h2>
        <p class="path-details">Départ le 18 décembre 2014 à 9h15, 4 sièges, 3€</p>
    </article>
</section>

<section class="">
    <h1>Derniers voyages demandés</h1>
    <article class="path">
        <h2 class="path-title">Paris - Marseille</h2>
        <p class="path-details">Départ le 25 mai 2015 à 12h30, 1 personne, 100€</p>
    </article>
    <article class="path">
        <h2 class="path-title">Marseille - Aix en provence</h2>
        <p class="path-details">Départ le 20 novembre 2014 à 8h30, 2 personnes, 4€</p>
    </article>
    <article class="path">
        <h2 class="path-title">Marseille - Aix en provence</h2>
        <p class="path-details">Départ le 22 novembre 2014 à 16h30, 5 personnes, 12.5€</p>
    </article>
    <article class="path">
        <h2 class="path-title">Martigues - Marseille</h2>
        <p class="path-details">Départ le 12 novembre 2014 à 8h00, 2 personnes, 8€</p>
    </article>
    <article class="path">
        <h2 class="path-title">Vitrolles - Salon de provence</h2>
        <p class="path-details">Départ le 18 décembre 2014 à 9h15, 4 personnes, 15€</p>
    </article>
</section>