<h1>Validation impossible</h1>
<p class="center-t">Le code de validation fourni n'a pas été reconnu.
si vous avez copié/collé le lien, vérifiez que vous l'avez pris en entier.<br>
Votre compte a peut-être déjà été validé. Essayez de vous connecter à votre compte.</p>
<p class="center-t">Si le problème persiste, contactez l'administrateur du site (<b><a href="mailto:contact@vroom.ovh">contact@vroom.ovh</a></b>) en précisant votre mail de connexion et le code de validation reçu.</p>