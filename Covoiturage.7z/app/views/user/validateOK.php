<h1>Compte validé !</h1>
<p>Votre compte a été validé, vous pouvez désormais vous connecter</p>